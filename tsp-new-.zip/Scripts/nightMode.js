function nightfall() {
    
   var element = document.querySelector("body");
    var card = document.querySelector(".card");
    
    if(element.classList.contains('t--summer') || element.classList.contains('t--autumn') || element.classList.contains('t--winter')){
        element.classList.remove('t--summer');
        element.classList.remove('t--autumn');
        element.classList.remove('t--winter');
        element.classList.add('t--dark'); 
        
    } else {
        element.classList.toggle('t--dark');
    }       
}