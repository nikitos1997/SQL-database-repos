/* these are scripts used for each page */

function goBack() {
  window.history.back();
}