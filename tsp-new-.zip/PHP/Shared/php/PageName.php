<?php
  session_start();
    echo'<div class="col-3 text-center"><h5>' . $_SESSION['htmlTitle'] . '</h5></div><br>'; 
  //Display page name of a specific page depending on which page the user is on
?>