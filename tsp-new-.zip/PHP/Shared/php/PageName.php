<?php
  session_start();
    echo'<div class="col-3 text-center"><h5>' . $_SESSION['htmlTitle'] . '</h5></div><br>'; 
?>
<!--PageName ends -->