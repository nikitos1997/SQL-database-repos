<?php
//  file: admin_import_course_csv.php
    session_start();
    require_once 'connect.php';
    require_once 'functions.php';

    //$staffid = $_SESSION['userid'];
     echo "Testing CSV import .1.0. </br>";
    //Code that imports courses

    if (isset($_POST['import'])) {
        $fileName = $_FILES['file']['tmp_name'];
        echo "Testing CSV import .2.0. </br>";
        if ($_FILES['file']['size'] > 0) {
            $file = fopen($fileName, 'r');
            echo "Testing CSV import .3.0. </br>";
            $count = 0;
            while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
                echo "Testing CSV import .4.1. </br>";
                $courseid = $column[0];
                $courseTitle = $column[1];
                $courseSubject = $column[2];
                $courseType = $column[3];
                $courseLevel = $column[4];
                $courseStart = $column[5];
                $courseEnd = $column[6];
                $courseYear = $column[7];
                echo "Testing CSV import .4.2. courseID: " . $courseid . "</br>";
                // ensure that this is a data set and not the header        
                if ($count >= 1){// put it instead if this repleace this if content
                    echo "Testing CSV import 4.3";
                    $SQL_stmt = "INSERT INTO course(courseID,courseTitle,courseSubject,courseType,courseLevel,courseStartDate,courseEndDate,courseYear) 
                    VALUES('".$courseid."','".$courseTitle."','".$courseSubject."','".$courseType."','".$courseLevel."',STR_TO_DATE('".$courseStart."', '%d/%m/%Y'),STR_TO_DATE('".$courseEnd."', '%d/%m/%Y'),'".$courseYear."')
                    ON DUPLICATE KEY UPDATE courseID = '".$courseid."'";
                     
                    $DBconnection->exec($SQL_stmt);
                    echo "Testing CSV import 4.4";
                }
                $count++;
            }
            goBack();
        }
    }
    
?>