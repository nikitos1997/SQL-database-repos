<body id="demo">
<?php
    session_start();
   # echo " start Step 0.0..<br>"; // for testing purposes
    require_once 'connect.php';//connects to the SQL database.
   # echo " start Step 1.0..<br>"; // for testing purposes
    require 'functions.php'; // connects to the functions.
    
    // Get the _SESSION user details.
    if (isset($_SESSION['lastName'])){
       # echo " start Step 2.0..<br>"; // for testing purposes
        $firstName = $_SESSION['firstName'];
        $lastName = $_SESSION['lastName'];
        $userid = $_SESSION['userid'];
        $userName = $firstName . " " . $lastName;
        // get course title
        $SQL_stmt = "SELECT DISTINCT courseTitle FROM course 
        INNER JOIN studentToCourse ON course.courseID = studentToCourse.stcCourseID
        INNER JOIN users ON users.userID = " . $userid . " and studentToCourse.stcStudentID = '" . $userid . "'";
        // now to run the query

        //
       # echo " start Step 2.0..<br>"; // for testing purposes
        // first prepare and excecurte
        $result = $DBconnection->query($SQL_stmt);
       # echo " start Step 2.1..<br>"; // for testing purposes
        // now get the data
        if ($row = $result->fetch()){
            // varify that it is a valid userID
           # echo " start Step 2.1.1..<br>"; // for testing purposes
            // Bind results by column name
            $courseTitle = $row['courseTitle'];
            // store session variables
            $_SESSION['courseTitle'] =  $courseTitle;
            // this varisable is also used for posting.

        }
        $submitTotal = getTotals ($userid, "Submitted");
        $approved = getTotals ($userid, "Approved");
        $pending = getStudentAwaitingDelivery($userid);
        $deliveredTotal = getDelivered($userid);
        $availableBalance = getStudentAvailableBalance($userid);
    }
?>
<div class="col-md-4 ml-3">   
      <h6>Outstanding balance: <span><?php echo $availableBalance ?></span></h6>                   
        <ul class="removeBullets">            
             <li>Submitted: <span><?php echo $submitTotal ?></span></li>
             <li>Approved: <span><?php echo $approved ?></span></li>
             <li>Awaiting delivery: <span><?php echo $pending ?></span></li>
             <li>Delivered: <span><?php $deliveredTotal ?></span></li>                      
        </ul>
    </div>
</div>
          <section class="content">
              <div class="row justify-content-center">
                  <article class="border col-lg-6 mt-2">
                      
                      When you visit the bursary request system, Lincoln college uses cookies and other methods to process your personal data in order to customize content and your site experience and analyze our traffic.

Please click "I Consent" to accept this use of your data. You will not be able to use the system until you consent to the use of your data.


                      
                      By submitting this form you are confirming that you are consenting to the bursary system holding and processing your personal data.
                  </article>
              </div>
          </section>
</body>                                       
          