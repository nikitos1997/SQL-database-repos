<?php
    session_start();
   # echo " start Step 0.0..<br>"; // for testing purposes
    require_once 'connect.php';//connects to the SQL database.
   # echo " start Step 1.0..<br>"; // for testing purposes
    require 'functions.php'; // connects to the functions.
    
    // Get the _SESSION user details.
    if (isset($_SESSION['lastName'])){
       # echo " start Step 2.0..<br>"; // for testing purposes
        $firstName = $_SESSION['firstName'];
        $lastName = $_SESSION['lastName'];
        $userid = $_SESSION['userid'];
        $userName = $firstName . " " . $lastName;
        // get course title
        $SQL_stmt = "SELECT DISTINCT courseTitle FROM course 
        INNER JOIN studentToCourse ON course.courseID = studentToCourse.stcCourseID
        INNER JOIN users ON users.userID = " . $userid . " and studentToCourse.stcStudentID = '" . $userid . "'";
        // now to run the query

        //
       # echo " start Step 2.0..<br>"; // for testing purposes
        // first prepare and excecurte
        $result = $DBconnection->query($SQL_stmt);
       # echo " start Step 2.1..<br>"; // for testing purposes
        // now get the data
        if ($row = $result->fetch()){
            // varify that it is a valid userID
           # echo " start Step 2.1.1..<br>"; // for testing purposes
            // Bind results by column name
            $courseTitle = $row['courseTitle'];
            // store session variables
            $_SESSION['courseTitle'] =  $courseTitle;
            // this varisable is also used for posting.

        }
        // get the data for the submitted requests
        $submitTotal = getTotals ($userid, "Submitted");
        $approved = getTotals ($userid, "Approved");
        $pending = getStudentAwaitingDelivery($userid);
        $deliveredTotal = getDelivered($userid);
        $availableBalance = getStudentAvailableBalance($userid);
    }
?>
<div class="col-md-4 ml-3">
          <?php
              echo '<h6>Outstanding balance: <span>' . $availableBalance . '</span></h6>';
          ?>
      </div>
       <div class="col-3">
           <ul class="removeBullets">
             <?php
                echo '<li>Submitted: <span>' . $submitTotal . '</span></li>';
                echo '<li>Approved: <span>' . $approved . '</span></li>';
                echo '<li>Awaiting delivery: <span>' . $pending . '</span></li>';
                echo '<li>Delivered: <span>' . $deliveredTotal . '</span></li>';
             ?>
           </ul>
       </div>           
 </div>
 <div class="accordion" id="accordionExample">
  <div class="cardy">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Is there car parking available at College?
        </button>
      </h5>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
        There is no car parking available for learners on college sites, however there are alternate public car parks available close by.

On production of a Blue Badge learners with a mobility disability may apply to Student Services for a car parking pass. The car parking pass is solely for the use of that learner and permits them to park in any of the College’s disabled parking spaces that are vacant.</div>
    </div>
  </div>
  <div class="cardy">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          I was bullied at school, what support is available to me when I come to College?
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
       Lincoln College aims to be a pleasant place for staff and students. This can’t happen if bullying or harassment takes place. If you think there is a problem with bullying or harassment, there is a Harassment Code of Practice and Procedure to follow.

Anyone who feels they are being bullied or harassed or has witnessed bullying or harassment can talk to any Named Person by contacting Student Service.

Other support services are available to all learners who are currently enrolled on a course including counselling and chaplaincy.</div>
    </div>
  </div>
     <div class="cardy">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Quick links
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
          <p>College Policies: <a href="https://moodle.lincolncollege.ac.uk/course/view.php?id=1602%20%22%20target%3D%5C%22_blank">Click Here</a></p>
         <p>Info for students: <a href="https://moodle.lincolncollege.ac.uk/course/view.php?id=1602">Click Here</a></p>
         <p>Monte safety care: <a href="http://lincolncollege.safetyhub.com/">Click Here</a></p>
         <p>Equality and diversity policy: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/203254/mod_resource/content/1/Equality%20and%20Diversity%20Policy.pdf">Click Here</a></p>
         <p>Internet, email and computer acceptable use policy: <a href="http://lincolncollege.safetyhub.com/">Click Here</a></p>
        <p>Safeguarding policy and procedures: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/203252/mod_resource/content/1/Safeguarding%20Policy.pdf">Click Here</a></p>
        <p>Malpractice and maladministration policies: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/181396/mod_resource/content/1/Malpractice%20%20and%20Maladministration.pdf">Click Here</a></p>
        </div>
  </div>
</div>
  
</div>