<?php
    session_start();
?>
<div class="row">
            <div class="dropdown col-3 ml-4 c-menu / t-menu">
                  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <i class="fas fa-list-ul"></i></a>
                       
                      <div class="dropdown-menu bg-primary" aria-labelledby="dropdownMenuLink">
                        <a class="dropdown-item" href="student_new_request.php">Create New Bursary</a>
                        <a class="dropdown-item" href="student_review_draft.php">Review My Drafts</a>
                        <a class="dropdown-item" href="student_submitted.php">My Submitted Forms</a>
                        <a class="dropdown-item" href="student_faq.php"> FAQ </a>
                        <a class="dropdown-item" href="student_agreement.php"> Terms and Conditions </a>
                        <a class="dropdown-item" href="student_home.php"> Home Page </a>
                    </div>
               </div>
