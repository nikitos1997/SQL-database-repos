<?php
        session_start();
        require 'connect.php'; 
        $count = 0;
        $q = $_REQUEST["q"];

        $yr = $_REQUEST["yr"];
        
        $lvl = $_REQUEST["lvl"];

        $tp = $_REQUEST["tp"];

        if(!empty($q))
        {
            $courseTitle = $q;
            $courseYear = $yr;
            $courseLevel = $lvl;
            $courseType = $tp;
            
            $SQL_stmt = "SELECT courseID FROM course
            WHERE courseTitle = '".$courseTitle."'
            AND courseYear = '".$courseYear."'
            AND courseLevel = '".$courseLevel."'
            AND courseType = '".$courseType."'";
            
            $result = $DBconnection->query($SQL_stmt);
        
            if ($row = $result->fetch()){
                 echo $row['courseID'];
            }
        }
?>