<?php
    mysqli_close ($connection);
?>