<?php
    session_start();
    require_once 'connect.php';//connects to the SQL database.

    require_once 'functions.php';

    $submitted = getAdminSubmitted();
    $approved = getAdminApproved();
    $waitDelivery = getAdminAwaitingDelivery();
?>  

   <div class="col-3">
       <?php
        echo '<ul class="list-group">
              <li class="list-group-item  border-0">Submitted: <span>'.$submitted.'</span></li>
              <li class="list-group-item  border-0">Approved: <span>'.$approved.'</span></li>
              <li class="list-group-item  border-0">Awaiting delivery: <span>'.$waitDelivery.'</span></li>
                        
        </ul>';
            ?>
    </div>
</div>
          
 <section class="container">
    <article>
                <p>
                    Hello and welcome to the bursary request system for lincoln college HE students. This system is designed to make it easier for staff of the college and students to make use of the money supplied by the bursary system. Part time students are given £250 and full time students are given £500. This money can be spent on courses, equipment and professional accreditaion. Faq's explains this further.
                    
                    </p>
        </article>
   </section>  
    