<?php
    session_start();
    require_once 'connect.php';//connects to the SQL database.
    require_once 'functions.php';

    $submitted = getAdminSubmitted();
    $approved = getAdminApproved();
    $waitDelivery = getAdminAwaitingDelivery();

    // drop down requirements on initial load (will run queries)
    // # - selectthat 
?>
     <div class="col-3">
       <?php
        echo '<ul class="list-group">
              <li class="list-group-item  border-0">Submitted: <span>'.$submitted.'</span></li>
              <li class="list-group-item  border-0">Approved: <span>'.$approved.'</span></li>
              <li class="list-group-item  border-0">Awaiting delivery: <span>'.$waitDelivery.'</span></li>
                        
        </ul>';
            ?>
</div>
</div>
            
   <section class="content">
              <div class="row justify-content-center">
                  <article class="border col-lg-6 mt-2">
                      
                      When you visit the bursary request system, Lincoln college uses cookies and other methods to process your personal data in order to customize content and your site experience and analyze our traffic.

Please click "I Consent" to accept this use of your data. You will not be able to use the system until you consent to the use of your data.


                      
                      By submitting this form you are confirming that you are consenting to the bursary system holding and processing your personal data.
                  </article>
              </div>
          </section>
</body>