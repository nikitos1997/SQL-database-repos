<?php
    session_start();
    require_once 'connect.php';//connects to the SQL database.

    // drop down requirements on initial load (will run queries)
    // # - select
    // 
?>
     <div class="col-3">
         <ul class="list-group">
             <li class="list-group-item  border-0">Submitted: <span>10</span></li>
             <li class="list-group-item  border-0">Approved: <span>8</span></li>
             <li class="list-group-item  border-0">Awaiting delivery: <span>YES</span></li>
         </ul>
     </div>
</div>
    
<div class="accordion z-depth-9" id="accordionExample">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          How does signing in work for students?
        </button>
      </h5>
    </div>
 
    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
          A student will first need to register using the register page, they will need to create a password here. This is where they will enter the pin number sent using the my students page and this will confirm it is the person assigned to that account. This will be sent to the email address of the student and the student can then login
        </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          What happpens when I approve a request?
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
          This is the final step of the bursary request system so the requested item can be purchased and then its status updated by you (Admin) when it is dispatched delivered etc
        </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          What happens if I reject a request?
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
          This bursary request will go back to the student with a marker saying it is rejected with your reason. The student can then create a new request with ammendments
          </div>
    </div>
  </div>
    <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Quick links
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
          <p>College Policies: <a href="https://moodle.lincolncollege.ac.uk/course/view.php?id=1602%20%22%20target%3D%5C%22_blank">Click Here</a></p>
         <p>Info for students: <a href="https://moodle.lincolncollege.ac.uk/course/view.php?id=1602">Click Here</a></p>
         <p>Monte safety care: <a href="http://lincolncollege.safetyhub.com/">Click Here</a></p>
         <p>Equality and diversity policy: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/203254/mod_resource/content/1/Equality%20and%20Diversity%20Policy.pdf">Click Here</a></p>
         <p>Internet, email and computer acceptable use policy: <a href="http://lincolncollege.safetyhub.com/">Click Here</a></p>
        <p>Safeguarding policy and procedures: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/203252/mod_resource/content/1/Safeguarding%20Policy.pdf">Click Here</a></p>
        <p>Malpractice and maladministration policies: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/181396/mod_resource/content/1/Malpractice%20%20and%20Maladministration.pdf">Click Here</a></p>
        </div>
  </div>
</div>
    