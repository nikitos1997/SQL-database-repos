<?php
    session_start();
    require_once 'connect.php';//connects to the SQL database.

require_once 'functions.php';

    $submitted = getAdminSubmitted();
    $approved = getAdminApproved();
    $waitDelivery = getAdminAwaitingDelivery();
?>  

   <div class="col-3">
       <?php
        echo '<ul class="list-group">
              <li class="list-group-item  border-0">Submitted: <span>'.$submitted.'</span></li>
              <li class="list-group-item  border-0">Approved: <span>'.$approved.'</span></li>
              <li class="list-group-item  border-0">Awaiting delivery: <span>'.$waitDelivery.'</span></li>
                        
        </ul>';
            ?>
    </div>

<form action="AdminReviewSubmission.php" method="POST">
        <table class="table table-striped">
   <thead class="thead-dark">
    <tr>
      <th scope="col">Student ID</th>
      <th scope="col">Student Name</th>
      <th scope="col">Request ID</th>
      <th scope="col">Date Submitted</th> 
      <th scope="col">Cost</th>
      <th scope="col">Available Funds</th>
      <th scope="col">Status</th>
      <th></th>
    </tr>
  </thead> 
  <tbody id="table">
     <?php 
          echo getAdminStudentSubmitted();
      
      ?>
</tbody>
</table> 
</form>   
</div>
</div><!-- container end -->
</body>
