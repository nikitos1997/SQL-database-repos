<?php
//  file: admin_import_course_csv.php
    session_start();
    require_once 'connect.php';
    require_once 'functions.php';

    //$staffid = $_SESSION['userid'];
     echo "Testing CSV import .1.0. </br>";
    //Code that imports an uploaded csv from staff to add his/her students

    if (isset($_POST['import'])) {
        $fileName = $_FILES['file']['tmp_name'];
        echo "Testing CSV import .2.0. </br>";
        if ($_FILES['file']['size'] > 0) {
            $file = fopen($fileName, 'r');
            echo "Testing CSV import .3.0. </br>";
            $count = 0;
            while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
                echo "Testing CSV import .4.1. </br>";
                $departmentID = $column[0];
                $departmentName = $column[1];
                $campusName = $column[2];
                echo "Testing CSV import .4.2. departmentID: " . $departmentID . "</br>";
                // ensure that this is a data set and not the header        
                if ($count >= 1){// put it instead if this repleace this if content
                    echo "Testing CSV import 4.3";
                    $SQL_stmt = "INSERT INTO department(departmentID,departmentName,departmentCampusName)
                    VALUES('".$departmentID."','".$departmentName."','".$campusName."')
                    ON DUPLICATE KEY UPDATE departmentID = '".$departmentID."'";
                    
                    $DBconnection->exec($SQL_stmt);
                    echo "Testing CSV import 4.4";
                }
                $count++;
            }
            goBack();
        }
    }
    
?>