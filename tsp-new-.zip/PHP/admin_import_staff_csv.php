<?php
    session_start();
    require_once 'connect.php';

    //$staffid = $_SESSION['userid'];
     echo "Testing CSV import .1.0. </br>";
    //Code that imports an uploaded csv from staff to add his/her students

    if (isset($_POST['import'])) {
        $fileName = $_FILES['file']['tmp_name'];
        echo "Testing CSV import .2.0. </br>";
        if ($_FILES['file']['size'] > 0) {
            $file = fopen($fileName, 'r');
            echo "Testing CSV import .3.0. </br>";
            $count = 0;
            while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
                echo "Testing CSV import .4.1. </br>";
                $departmentID = $column[0];
                
                $userid = $column[1];//Store user id for future inserts
                $userType = $column[6];
                $staffEmail = $column[7];
                $gender = $column[5];
                echo "Testing CSV import .4.2. userID: " . $userid . "</br>";
                // ensure that this is a data set and not the header        
                if ($count >= 1){// put it instead if this repleace this if content
                    echo "Testing CSV import .5.1. Dob: " . $column[4] . "</br>";
                    //Generate student email based on ID
                    echo "Gender is:".$gender."</br>";
                    if($gender == "Male")
                    {
                        $gender = 1;
                        echo "Gender is:".$gender."</br>";
                    }
                    if($gender == "Female")
                    {
                        $gender = 0;
                        echo "Gender is:".$gender."</br>";
                    }
                    echo "Testing CSV import .5.2. </br>";
                    echo $staffEmail;
                    //Insert into users
                    $SQL_stmt = "INSERT INTO users(userID,userFirstName,userLastName,userEmail,userType,userPIN,userActive)
                    VALUES('" . $userid . "','" . $column[2] . "','" . $column[3] . "','" . $staffEmail . "', '".$userType."' , FLOOR( RAND() * (9999-1000) + 1000),1)
                    ON DUPLICATE KEY UPDATE userID = '".$userid."'";
                    echo "Testing CSV import .5.3. </br>";
                    
                    $DBconnection->exec($SQL_stmt);
                    echo "Testing CSV import .5.3.1 </br>";
                    
                    if($userType == "Staff" || $userType == "staff")
                    {
                        //Insert to staff table now
                        $SQL_stmt = "INSERT INTO staff(staffID) VALUES('".$userid."')
                        ON DUPLICATE KEY UPDATE staffID = '".$userid."'";

                        $DBconnection->exec($SQL_stmt);
                        echo "Testing CSV import .5.3.2 </br>";

                        //Link to department of the staff member
                        $SQL_stmt = "INSERT INTO staffToDepartment(stDepartmentID, stStaffID)
                        VALUES('".$departmentID."','".$userid."')";
                        $DBconnection->exec($SQL_stmt);

                        echo "Testing CSV import .5.3.3 </br>";
                    }
                    if($userType == "Admin" || $userType == "admin")
                    {
                        echo "Testing CSV import .5.3.4 </br>";
                        //Insert to staff table now
                        $SQL_stmt = "INSERT INTO admin(adminID) VALUES('".$userid."')
                        ON DUPLICATE KEY UPDATE adminID = '".$userid."'";

                        $DBconnection->exec($SQL_stmt);
                        echo "Testing CSV import .5.3.4.1 </br>";
                    }
                    
                }
                $count++;
            }
        }
    }
    
?>