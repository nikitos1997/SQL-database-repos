<?php
   session_start();
   # echo " start Step 0.0..<br>"; // for testing purposes
   require_once 'connect.php';//connects to the SQL database.
   # echo " start Step 1.0..<br>"; // for testing purposes
   require 'functions.php'; // connects to the functions.
    
    // Get the _SESSION user details.
    if (isset($_SESSION['lastName'])){
       # echo " start Step 2.0..<br>"; // for testing purposes
        $firstName = $_SESSION['firstName'];
        $lastName = $_SESSION['lastName'];
        $userid = $_SESSION['userid'];
        $userType = $_SESSION['userType'];
        $userName = $firstName . " " . $lastName;
        // get course title of a staff member
        $SQL_stmt = "SELECT DISTINCT courseTitle from course 
        inner join departmentsStaffCourseStudents on course.courseID = departmentsStaffCourseStudents.bscsCourseID
        and departmentsStaffCourseStudents.bscsStaffID = '" . $userid . "'";
        // now to run the query

        //
       # echo " start Step 2.0..<br>"; // for testing purposes
        // first prepare and excecurte
        $result = $DBconnection->query($SQL_stmt);
       # echo " start Step 2.1..<br>"; // for testing purposes
        // now get the data
        if ($row = $result->fetch()){
            // varify that it is a valid userID
           # echo " start Step 2.1.1..<br>"; // for testing purposes
            // Bind results by column name
            $courseTitle = $row['courseTitle'];
            // store session variables
            $_SESSION['courseTitle'] =  $courseTitle; // Course title is defined for staff to display
            // this varisable is also used for posting.

        }
         $submittedTotal = getStaffTotals($userid,$userType,"Submitted");
         $approvedTotal = getStaffApproved($userid,$userType,"Approved");
         $awaitingDelivery = getStaffAwaitingDelivery($userid,$userType);
    }
?>     
<body id="demo">
                <div class="col-md-4 ml-4">
                    <ul class="removeBullets">
                       <?php
                       echo'<li>Submitted: '. $submittedTotal .'</li>';
                       echo'<li>Approved: '. $approvedTotal .'</li>';
                       echo'<li>Awaiting delivery: '. $awaitingDelivery .'</li>';
                          ?>
                    </ul>
                </div>
          <section class="content">
              <div class="row justify-content-center">
                  <article class="border col-lg-6 mt-2">
                      
                     When you visit the bursary request system, Lincoln college uses cookies and other methods to process your personal data in order to customize content and your site experience and analyze our traffic.

Please click "I Consent" to accept this use of your data. You will not be able to use the system until you consent to the use of your data.
                      
                      By submitting this form you are confirming that you are consenting to the bursary system holding and processing your personal data.
                  
                      
                  </article>
              </div>
          </section>
          
          
               </div>
            </form>
          </section>
</body>