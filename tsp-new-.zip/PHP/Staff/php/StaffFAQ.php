<?php
   session_start();
   # echo " start Step 0.0..<br>"; // for testing purposes
   require_once 'connect.php';//connects to the SQL database.
   # echo " start Step 1.0..<br>"; // for testing purposes
   require 'functions.php'; // connects to the functions.
    
    // Get the _SESSION user details.
    if (isset($_SESSION['lastName'])){
       # echo " start Step 2.0..<br>"; // for testing purposes
        $firstName = $_SESSION['firstName'];
        $lastName = $_SESSION['lastName'];
        $userid = $_SESSION['userid'];
        $userType = $_SESSION['userType'];
        $userName = $firstName . " " . $lastName;
        // get course title of a staff member
        $SQL_stmt = "SELECT DISTINCT courseTitle from course 
        inner join departmentsStaffCourseStudents on course.courseID = departmentsStaffCourseStudents.bscsCourseID
        and departmentsStaffCourseStudents.bscsStaffID = '" . $userid . "'";
        // now to run the query

        //
       # echo " start Step 2.0..<br>"; // for testing purposes
        // first prepare and excecurte
        $result = $DBconnection->query($SQL_stmt);
       # echo " start Step 2.1..<br>"; // for testing purposes
        // now get the data
        if ($row = $result->fetch()){
            // varify that it is a valid userID
           # echo " start Step 2.1.1..<br>"; // for testing purposes
            // Bind results by column name
            $courseTitle = $row['courseTitle'];
            // store session variables
            $_SESSION['courseTitle'] =  $courseTitle; // Course title is defined for staff to display
            // this varisable is also used for posting.

        }
         $submittedTotal = getStaffTotals($userid,$userType,"Submitted");
         $approvedTotal = getStaffApproved($userid,$userType,"Approved");
         $awaitingDelivery = getStaffAwaitingDelivery($userid,$userType);
    }

?>
                <div class="col-md-4 ml-4">
                    <ul class="removeBullets">
                      <?php
                       echo'<li>Submitted: '. $submittedTotal .'</li>';
                       echo'<li>Approved: '. $approvedTotal .'</li>';
                       echo'<li>Awaiting delivery: '. $awaitingDelivery .'</li>';
                          ?>
                    </ul>
                </div>
    </div>

<div class="container">
            
  <div class="row m-5"><!--table selectiom START -->  
  <div class="accordion z-depth-9" id="accordionExample">
  <div class="cardy">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          How does signing in work for students?
        </button>
      </h5>
    </div>
 
    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
          A student will first need to register using the register page, they will need to create a password here. This is where they will enter the pin number sent using the my students page and this will confirm it is the person assigned to that account. This will be sent to the email address of the student and the student can then login
        </div>
    </div>
  </div>
  <div class="cardy">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Can I see which students are assigned to me?
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
          Yes. All students that you manage can be seen on the my students page
        </div>
    </div>
  </div>
  <div class="cardy">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Can I create the same bursary request for multiple students?
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
          Yes. This is possible on the create new bursary request page. Simply select more than one student on the table on the right side of the page.
        </div>
    </div>
  </div>
   <div class="cardy">
    <div class="card-header" id="headingFour">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          Quick links
        </button>
      </h5>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
      <div class="card-body">
          <p>College Policies: <a href="https://moodle.lincolncollege.ac.uk/course/view.php?id=1602%20%22%20target%3D%5C%22_blank">Click Here</a></p>
         <p>Info for students: <a href="https://moodle.lincolncollege.ac.uk/course/view.php?id=1602">Click Here</a></p>
         <p>Monte safety care: <a href="http://lincolncollege.safetyhub.com/">Click Here</a></p>
         <p>Equality and diversity policy: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/203254/mod_resource/content/1/Equality%20and%20Diversity%20Policy.pdf">Click Here</a></p>
         <p>Internet, email and computer acceptable use policy: <a href="http://lincolncollege.safetyhub.com/">Click Here</a></p>
        <p>Safeguarding policy and procedures: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/203252/mod_resource/content/1/Safeguarding%20Policy.pdf">Click Here</a></p>
        <p>Malpractice and maladministration policies: <a href="https://moodle.lincolncollege.ac.uk/pluginfile.php/181396/mod_resource/content/1/Malpractice%20%20and%20Maladministration.pdf">Click Here</a></p>
        </div>
  </div>
</div>
</div>
</div>
</div>
</body>


