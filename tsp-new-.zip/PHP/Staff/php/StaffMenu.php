<?php
    session_start();
?>
<div class="row">
            <div class="dropdown col-3 ml-4">
                  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <i class="fas fa-list-ul"></i></a>
                       
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <a class="dropdown-item" href="staff_student_submissions.php"> Review Student Submissions</a>
                        <a class="dropdown-item" href="staff_new_bursary_request.php"> Create New Bursary </a>
                        <a class="dropdown-item" href="staff_submitted_forms.php"> My Submitted Forms </a>
                        <a class="dropdown-item" href="staff_review_drafts.php"> Review My Drafts </a>
                        <a class="dropdown-item" href="staff_history.php"> My History </a>
                        <a class="dropdown-item" href="staff_student_history.php"> Student's History </a>
                        <a class="dropdown-item" href="staff_faq.php"> FAQ </a>
                        <a class="dropdown-item" href="staff_agreement.php"> Agreement Form </a>
                        <a class="dropdown-item" href="staff_home.php"> Home Page </a>
                    </div>
            </div><!-- Menu ends -->
<!-- </div> -->