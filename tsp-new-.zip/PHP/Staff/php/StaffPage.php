<?php
  session_start();
    echo'<div><li class="list-group-item  border-1">' . $_SESSION['htmlTitle'] . '</li></div>';
?>