<?php
        session_start();

        require_once 'connect.php';

        $userid = 0;
        $activated = false;

        if (isset($_POST['submit'])){

        $submitButtons = $_POST['submit'];

        // now let's split the result
        $item = split("_", $submitButtons);

        $itemName = $item[0];

        // for user id
        $itemValue = $item[1];

        $userid = $itemValue;
        // for activating user
        if ($itemName == 'activate'){
            
            //Activate user.
            $SQL_stmt="UPDATE users SET userAccessGranted = 1 WHERE userID = '".$userid."'";
            $DBconnection->exec($SQL_stmt);
            
            $activated = true;
            
            //Finished.
        }
        if($activated == true)//Student has been activated
        {
            header ("Location: staff_view_students.php? activity=account_activated");
        }
        if($activated == false)
        {
            header ("Location: staff_view_students.php? activity=error_activating");
        }    
}
?>