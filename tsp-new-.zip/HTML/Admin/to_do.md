1. Move menu drop down closer to header (done)
2. Move Price, Postage and Additional fees label above input(done).
3. Center Review Student submission oustanding page. Outstanding amount only show ups when studet selected.(done) 
4. Review student submissions: tables: three columns ID, Name,sub date, status.(done) Clicking on table form propogates student/staff data to form on left.
5. Change select field to Eddie's buttons.(not applicable for form)
6. Set up mySQL article: https://community.c9.io/t/setting-up-mysql/1718