## file name    : PopulateDB.sql
## Created by   : Nick Skripnikov
## Date created : 04/01/2019
## Purpose      :- populate Bursary System (bursary_database) database with sample test data
## Notes        :-
## last updated : 03/02/2019 by: Nick Skripnikov & Mike Wright
## last updated : 07/02/2019 by: Mike Wright
## last updated : 09/02/2019 by: Nick Skripnikov
## last updated : 13/02/2019 by: Nick Skripnikov & Danny Mc
## last updated : 23/03/2019 by: Mike Wright
## last updated : 24/03/2019 by: Mike Wright
## change made  : 
##               - Added users (students, lecturers, admins) from different courses.
##               - added associated course data for new users.
##               - added some order data.
##               - added USE, so as data is added to the correct database.
##               - remarked-in some md5 encrypted passwords.
##               - removed pre-set user passwords.
SQL_Scripts/PropogateDB.sql
##               - update query/table insert with ‘courseLevel’ data (used guess ‘courseID’ to ‘courseLevel)’.
##               - updated query to mach table change of "bRequestsDraft" to "bRequestsStatus ENUM" in "bursaryRequests" table
##               - Added additional courses and users and years
##               - removed all non required users from DB as to be added through Staff.csv or Student.csv files in staff of admin sections
##               - removed all non required courses and departments, as now imported within app


# connect to the Busary Request Database to be abble to add data
USE bursary_database;

#
#--- drop the DB WEB admin control user
#
DROP USER 'WEBAuth';
/* create test DB WEB admin*/
CREATE USER 'WEBAuth' IDENTIFIED BY 'WEBAuthPW';

/*give web admin SELECT and INSERT*/
GRANT ALL ON bursary_database.*  TO 'WEBAuth';
#  PasswordA
#-------Admin user insertion------------#
  # ++++++ need to create a bursaryAdministator user account with a fixed Pin, and this is the account used to..
  # ++++++ .. initialy log into the bursary system and register staff and supply staff with their pins ++++++ #
INSERT INTO users (userID, userFirstName, userLastName, userEmail, userType, userActive,userPIN,userRegistered,userAccessGranted)
VALUES (4561,"Bursary","Administrator", 'SSmith@lincolncollege.ac.uk', "Admin", '1', '2877','1','1');


# --END-- #