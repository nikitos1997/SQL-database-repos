## file name    : PopulateDB.sql
## Created by   : Nick Skripnikov
## Date created : 04/01/2019
## Purpose      :- populate Bursary System (bursary_database) database with sample test data
## Notes        :-
## last updated : 03/02/2019 by: Nick Skripnikov & Mike Wright
## last updated : 07/02/2019 by: Mike Wright
## last updated : 09/02/2019 by: Nick Skripnikov
## last updated : 13/02/2019 by: Nick Skripnikov & Danny Mc
## last updated : 23/03/2019 by: Mike Wright
## change made  : 
##               - Added users (students, lecturers, admins) from different courses.
##               - added associated course data for new users.
##               - added some order data.
##               - added USE, so as data is added to the correct database.
##               - remarked-in some md5 encrypted passwords.
##               - removed pre-set user passwords.
##               - update query/table insert with ‘courseLevel’ data (used guess ‘courseID’ to ‘courseLevel)’.
##               - updated query to mach table change of "bRequestsDraft" to "bRequestsStatus ENUM" in "bursaryRequests" table
##               - Added additional courses and users and years
##               - removed all non required users from DB as to be added through Staff.csv or Student.csv files in staff of admin sections


# connect to the Busary Request Database to be abble to add data
USE bursary_database;

#
#--- drop the DB WEB admin control user
#
DROP USER 'WEBAuth';
/* create test DB WEB admin*/
CREATE USER 'WEBAuth' IDENTIFIED BY 'WEBAuthPW';

/*give web admin SELECT and INSERT*/
GRANT ALL ON bursary_database.*  TO 'WEBAuth';
#  PasswordA
#-------Admin user insertion------------#
  # ++++++ need to create a bursaryAdministator user account with a fixed Pin, and this is the account used to..
  # ++++++ .. initialy log into the bursary system and register staff and supply staff with their pins ++++++ #
INSERT INTO users (userID, userFirstName, userLastName, userEmail, userType, userActive,userPIN,userRegistered,userAccessGranted)
VALUES (4561,"Bursary","Administrator", 'SSmith@lincolncollege.ac.uk', "Admin", '1', '2877','1','1');

INSERT INTO department(departmentID,departmentName,departmentCampusName)
VALUES ("CompLincCol1001","Bishops building","Lincoln");
INSERT INTO department(departmentID,departmentName,departmentCampusName)
VALUES ("HairLincCol1111","Abbey building","Lincoln");
INSERT INTO department(departmentID,departmentName,departmentCampusName)
VALUES ("SiemensLincCol1002","Cathedral building","Lincoln");

#-------Course table insertion------------#
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEBCSIT111", "BCs Computer Science", "Information Technology", "Full_Time", '4', "2017-09-05", "2018-06-30","2017/2018");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEBCSIT112", "BCs Computer Science", "Information Technology", "Part_Time", '4', "2017-09-05", "2018-06-30","2017/2018");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEMNG001", "BCs Mechanical Engineering", "Mechanical Engineering", "Full_Time", '4', "2017-09-05", "2018-06-30","2017/2018");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEHAIR001", "BCs Hair and beauty", "Hair and beauty", "Full_Time", '4', "2018-09-05", "2017-06-30","2017/2018");
# - courseID is a gues here, based on new level
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEBCSIT121", "BCs Computer Science", "Information Technology", "Full_Time",'5', "2018-09-05", "2019-06-30","2018/2019");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEBCSIT122", "BCs Computer Science", "Information Technology", "Part_Time", '5', "2018-09-05", "2019-06-30","2018/2019");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEMNG011", "BCs Mechanical Engineering", "Mechanical Engineering", "Full_Time", '5', "2018-09-05", "2019-06-30","2018/2019");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEHAIR011", "BCs Hair and beauty", "Hair and beauty", "Full_Time", '5', "2018-09-05", "2019-06-30","2018/2019");
# - courseID is a gues here, based on new level
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEBCSIT131", "BCs Computer Science", "Information Technology", "Full_Time",'6', "2019-09-05", "2020-06-30","2019/2020");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEBCSIT132", "BCs Computer Science", "Information Technology", "Part_Time", '6', "2019-09-05", "2020-06-30","2019/2020");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEMNG021", "BCs Mechanical Engineering", "Mechanical Engineering", "Full_Time", '6', "2019-09-05", "2020-06-30","2019/2020");
INSERT INTO course(courseID, courseTitle, courseSubject, courseType, courseLevel, courseStartDate, courseEndDate, courseYear)
VALUES ("HEHAIR021", "BCs Hair and beauty", "Hair and beauty", "Full_Time", '6', "2019-09-05", "2020-06-30","2019/2020");



# --END-- #