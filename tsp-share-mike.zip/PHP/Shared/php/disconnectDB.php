<?php
// file name: disconnectDB.php
// author: Mike Wright
// date created: 27/01/2019
    mysqli_close ($connection);
?>