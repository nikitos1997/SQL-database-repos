<?php
  session_start();
    echo'<div><li class="list-group-item  border-1">' . $_SESSION['htmlTitle'] . '</li></div>'; 
  //Display page name of a specific page depending on which page the user is on
?>