<?php
    // start the session
    session_start();
    // connect to the database
    # echo " start Step 0.0..<br>"; // for testing purposes
    #require_once '../../connect.php';//connects to the SQL database.
    //include (Student/php/StudentReviewDraft_A.php);
    //connect to the functions
    # echo " start Step 1.0..<br>"; // for testing purposes
    #require 'functions.php'; // connects to the functions. // seems to fails to load page if this is loaded.
    // get session variables.
    $firstName = $_SESSION['firstName'];
    $lastName = $_SESSION['lastName'];
    $userid = $_SESSION['userid'];
    $userName = $firstName . " " . $lastName;
    $courseTitle = $_SESSION['courseTitle'];
    $courseTutorFirstName = $_SESSION['courseTutorFirstName'];
    $courseTutorLastName = $_SESSION['courseTutorLastName'];
    $courseTutorId = $_SESSION['courseTutorId'];
?>
<div class="modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="ModalLongTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLongTitle">Bursary request</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                
                <form class="ml-2" action="requestSave.php" method="POST">
                        <div class="form-group row">
                             <label for="fullName" class="col-sm-2 col-form-label">Full Name:</label>
                             <div class="col-sm-10">
                               <?php
                                  echo '<input type="text" class="form-control" id="fullName" disabled value="' . $userName . '" placeholder="Auto-generated field">';
                                ?>
                             </div>

                        </div>
                        <div class="form-group row">
                             <label for="course" class="col-sm-2 col-form-label">Course:</label>
                             <div class="col-sm-10">
                               <?php
                                  echo '<input type="text" class="form-control" id="course" disabled value="' . $courseTitle . '" placeholder="Auto-generated field">';
                                ?>
                             </div>
                        </div>
                        <div class="form-group row">
                             <label for="tutor" class="col-sm-2 col-form-label">Tutor:</label>
                             <div class="col-sm-10">
                               <?php
                                 echo '<input type="text" class="form-control" id="tutor" disabled value="' . $courseTutorFirstName . ' ' . $courseTutorLastName . '" placeholder="Auto-generated field">';
                                ?>
                             </div>
                        </div>

<?php
    // check to see which button was pressed.
    //// set a counter for this purpose
#    $count = 1;
    //// set the name="submit" variable
    //IF statement does not work with 2 == only 1 =
    //if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['submitit']){
 /*   if (isset($_POST['submitit'])){
        echo " Loop .if.yes. Step 1.0..: " . $count . "<br>"; // for testing purposes
        $submitButtons = $_POST['submitit'];
        $requestTempId = 'fieldRequestId' . $count;
        echo " Loop .if.yes. Step 2.0..:" . $requestTempId . "<br>";
        echo " Loop .if.yes. Step 2.0..: " . $count . "<br>"; // for testing purposes
        echo "Submit button: ".$submitButtons."<br>"; //No value (empty)
        $requestid = $_POST[$requestTempId];
        echo "Submit button: ".$requestid."<br>"; //No value (empty)
        foreach ($_POST as $keyName => $keyValue){
            echo " Loop .if.yes. Step 3.0..: " . $keyName .  ", " . $keyValue . "<br>"; // for testing purposes
            // look for buttons available that were pressed
            /// look to see if edit_ was pressed
            $editVar = 'edit_' . $count;
            #if (isset($_POST['submit'] == $editVar)){
                // carry out this action
                echo " Loop .1.2. Step 1.0..<br>"; // for testing purposes
            #    $requestCoutID = 'requestid' . $count;
                // get the ID of the request
            #    $requestid = $_POST[$requestCoutID];
                ### now process the required actions
                /////
                //Outputting draft request item info when edit button is pressed UNDER TESTING
                //Fetch request id for the draft
                $SQL_stmt = "SELECT brItemID AS 'itemID', bursaryRequests.bRequestsID AS 'requestid' FROM bursaryRequests
                INNER JOIN itemsAndRequests ON bursaryRequests.bRequestsID = itemsAndRequests.RequestID
                INNER JOIN bursaryRequestItems ON bursaryRequestItems.brItemID = itemsAndRequests.ItemID
                AND itemsAndRequests.StudentID = ".$userid." AND bursaryRequests.bRequestsStatus = 'Draft'";
                $requestid = 0;
                $category = 0;
                $itemDesc = 0;
                $url = 0;
                $price = 0;
                $postage = 0;
                $addCharges = 0;
                
                $result = $DBconnection->query($SQL_stmt);
                
                // now get the data
                if ($row = $result->fetch()){
                    
                    $requestid = $row['requestid'];
                }
                
                //Using the request id, find the item info 
                $SQL_stmt = "SELECT brItemCategory AS 'category', brItemDesc AS 'item_description',
                brItemURL AS 'URL', brItemPrice AS 'price', brItemPostage AS 'postage',
                brItemAdditionalCharges AS 'additional_charges' FROM bursaryRequestItems
                INNER JOIN itemsAndRequests ON itemsAndRequests.ItemID = bursaryRequestItems.brItemID 
                AND itemsAndRequests.RequestID = " . $requestid . "
                AND itemsAndRequests.StudentID = '" . $userid . "'";
                
                $result = $DBconnection->query($SQL_stmt);
                
                // now get the data
                $count = 1;
                while ($row = $result->fetch()){
                    // loop through the request results
                    $itemcategory = $row['category'];
                    $itemdescription = $row['item_description'];
                    $itemUrl = $row['URL'];
                    $itemprice = $row['price'];
                    $itempostage = $row['postage'];
                    $itemadditionalcharges = $row['additional_charges'];

                    // output data from query
                    echo '<div class="row">
                            <h5 class="m-2">Item ' . $count . '</h5>
                        </div>
                        <div class="form-group row">
                            <label for="categoryField" class="col-sm-2 col-form-label">Category field:</label>
                            <div class="col-sm-10 mt-2">
                                <select class="custom-select" id="categoryField">';                    
                    echo '<option selected name="itemcategory' . $count . '">' . $itemcategory . '</option>';
                    echo '<option value="1">Qualification</option>';
                    echo '<option value="2">Equipment</option>';
                    echo '<option value="3">Events</option>';
                    echo '<option value="4">Professional accreditation</option>';
                    echo '<option value="5">Vocational placement</option>';
                    echo '</select>';

                    // now output the data
                    echo '      </div>
                            </div>
                            <div class="form-group">
                                <div>';
                                    echo '<label for="itemDescription' . $count . '">Item description:</label>';
                                    echo '<textarea class="form-control" id="itemDescription' . $count . '" name="itemdescription' . $count . '" rows="2">' . $itemdescription . '</textarea>';
                                    echo '</div>
                            </div>
                
                            <div class="form-group">
                                <div>
                                    <input type="text" class="form-control" name="itemUrl' . $count . '" placeholder="URL to the item:" value="' . $itemUrl . '" />
                                </div>
                            </div>
                            
                            <div class="form-row justify-content-between text-center">
                                <div class="form-group col-md-2">
                                <label for="price' . $count . '">Price:</label>
                                <input type="text" class="form-control" name="itemprice' . $count . '" id="price" value="' . $itemprice . '" />
                                </div>
                                <div class="form-group col-md-2">
                                <label for="postage' . $count . '">Postage:</label>
                                <input type="text" class="form-control" name="itempostage' . $count . '" id="postage" value="' . $itempostage . '" />
                                </div>
                                <div class="form-group col-md-3">
                                <label for="additionalFees' . $count . '">Additional Fees:</label>
                                <input type="text" class="form-control" name="itemadditionalcharges' . $count . '" id="additionalFees" value="' . $itemadditionalcharges . '" />
                                </div>
                                </div>';
                        // cycle counter
                        $count++;
                

                /////
                // break out of the for loop*/
               // break;
           # }
 /*           /// look to see if delete_ was pressed
            if (isset($_POST['delete_' . $count])){
                //carry out this action
                echo " Loop .2. Step 1.0..<br>"; // for testing purposes
                ### now process the required actions

                // break out of the for loop
                break;
            }
            /// cycle the counter
            $count++;
       
    }/*# else{
        echo " Loop .if.no. Step 1.0..: " . $count . "<br>"; // for testing purposes

        //Outputting draft request item info when edit button is pressed UNDER TESTING
        //Fetch request id for the draft
        $SQL_stmt = "SELECT brItemID AS 'itemID', bursaryRequests.bRequestsID AS 'requestid' FROM bursaryRequests
        INNER JOIN itemsAndRequests ON bursaryRequests.bRequestsID = itemsAndRequests.RequestID
        INNER JOIN bursaryRequestItems ON bursaryRequestItems.brItemID = itemsAndRequests.ItemID
        AND itemsAndRequests.StudentID = ".$userid." AND bursaryRequests.bRequestsStatus = 'Draft'";
        $requestid = 0;
        $category = 0;
        $itemDesc = 0;
        $url = 0;
        $price = 0;
        $postage = 0;
        $addCharges = 0;

        $result = $DBconnection->query($SQL_stmt);

 #       // now get the data
 #       if ($row = $result->fetch()){
#
 #           $requestid = $row['requestid'];
  #      }

        //Using the request id, find the item info 
        $SQL_stmt = "SELECT brItemCategory AS 'category', brItemDesc AS 'item_description',
        brItemURL AS 'URL', brItemPrice AS 'price', brItemPostage AS 'postage',
        brItemAdditionalCharges AS 'additional_charges' FROM bursaryRequestItems
        INNER JOIN itemsAndRequests ON itemsAndRequests.ItemID = bursaryRequestItems.brItemID 
        AND itemsAndRequests.RequestID = " . $requestid . "
        AND itemsAndRequests.StudentID = '" . $userid . "'";

        $result = $DBconnection->query($SQL_stmt);

        // now get the data
        $count = 1;
        while ($row = $result->fetch()){
            // loop through the request results
            $itemcategory = $row['category'];
            $itemdescription = $row['item_description'];
            $itemUrl = $row['URL'];
            $itemprice = $row['price'];
            $itempostage = $row['postage'];
            $itemadditionalcharges = $row['additional_charges'];

            // output data from query
            echo '<div class="row">
                    <h5 class="m-2">Item ' . $count . '</h5>
                </div>
                <div class="form-group row">
                    <label for="categoryField" class="col-sm-2 col-form-label">Category field:</label>
                    <div class="col-sm-10 mt-2">
                        <select class="custom-select" id="categoryField">';                    
            echo '<option selected name="itemcategory' . $count . '">' . $itemcategory . '</option>';
            echo '<option value="1">Qualification</option>';
            echo '<option value="2">Equipment</option>';
            echo '<option value="3">Events</option>';
            echo '<option value="4">Professional accreditation</option>';
            echo '<option value="5">Vocational placement</option>';
            echo '</select>';

            // now output the data
            echo '      </div>
                    </div>
                    <div class="form-group">
                        <div>';
                            echo '<label for="itemDescription' . $count . '">Item description:</label>';
                            echo '<textarea class="form-control" id="itemDescription' . $count . '" name="itemdescription' . $count . '" rows="2">' . $itemdescription . '</textarea>';
                            echo '</div>
                    </div>

                    <div class="form-group">
                        <div>
                            <input type="text" class="form-control" name="itemUrl' . $count . '" placeholder="URL to the item:" value="' . $itemUrl . '" />
                        </div>
                    </div>

                    <div class="form-row justify-content-between text-center">
                        <div class="form-group col-md-2">
                        <label for="price' . $count . '">Price:</label>
                        <input type="text" class="form-control" name="itemprice' . $count . '" id="price" value="' . $itemprice . '" />
                        </div>
                        <div class="form-group col-md-2">
                        <label for="postage' . $count . '">Postage:</label>
                        <input type="text" class="form-control" name="itempostage' . $count . '" id="postage" value="' . $itempostage . '" />
                        </div>
                        <div class="form-group col-md-3">
                        <label for="additionalFees' . $count . '">Additional Fees:</label>
                        <input type="text" class="form-control" name="itemadditionalcharges' . $count . '" id="additionalFees" value="' . $itemadditionalcharges . '" />
                        </div>
                        </div>';
                // cycle counter
                $count++;
        }
#}*/

// finish the display of HTML
?>
</div>
<div class="row mt-3 mb-5">
    
    <div class="col-5 mb-5 text-right">
        <button type="submit" name="submit" value="saveRequest" style="width: 38%;" class="btn btn-primary" id="Save" wide="45">Save</button>
    </div>
  <!-- need to add button for adding new item (+)-->
    <div class="col-5 mb-5 text-right">
        <button type="submit" name="submit" value="submitRequest" style="width: 38%;" class="btn btn-success" id="Submit">Submit</button>
    </div>
</div>
</form>

