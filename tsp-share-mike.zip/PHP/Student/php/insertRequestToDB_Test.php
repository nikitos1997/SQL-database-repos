<!--File created for testing purposes-->
<!-- If you want to change something - create your own file and modify -->
<!-- Yea, I am talking to you, Mike and Nick! Begon Thots! -->


<!-- NOT WORKING -->
<?php
  
//Create sybmission conditional and initialize the $errors array
//This script both display and handle the HTML form
  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = array(); //initialize an error array.
    
    //check for item description
    if(empty($_POST['itemdescription'])) {
      $errors[] = 'You forgot to enter item description.';
    } else {
      $txbItemDescription = $_POST['itemdescription'];
    }
    
    //check for item URL
    if(empty($_POST['itemUrl'])) {
      $errors[] = 'You forgot to enter Item URL.';
    } else {
      $itemUrl = $_POST['itemUrl'];
    }
    //check for price
    if(empty($_POST['itemprice'])) {
      $errors[] = 'You forgot to enter Item price.';
    } else {
      $txbPrice = $_POST['itemprice'];
    }
    //check for postage fees
    if(empty($_POST['itempostage'])) {
      $errors[] = 'You forgot to enter Item postage fee.';
    } else {
      $txbPostage = $_POST['itempostage'];
    }
    //check for justification field
    if(empty($_POST['justification'])) {
      $errors[] = 'You forgot to enter justification for item(s).';
    } else {
      $justification  = $_POST['justification'];
    }
    //IF everything's OK.
    if (empty($errors)) {
      //connect to database
      require ('connect.php');
      //Make a query:
      $SQL_stmt = "INSERT INTO bursaryRequests (bRequestsCourseID, bRequestsStaffID, bRequestsJustification, bRequestsRequestDate)
                   VALUES ()";
      //Run query
      $result = $DBconnection->query($SQL_stmt);
      if($result) { //if it ran OK
        //Print message
        echo "<h1>Submission Successful!</h1>";
      } else { //if it did NOT run OK
        echo "<h1>System Error</h1>
        <p>Request could not be accepted.</p>";
        //Debugging message:
        echo "<p>" . mysqli_error($DBconnection) . '<br /><br />Query: ' . $SQL_stmt . '</p>';
        
      } //END of if($results) IF.
      
    } else { //report the errors
      echo "<h1>Error!</h1>
      <p>The following error(s) occured:<br />";
      foreach($errors as $msg) { //Print each error
        echo " - $msg<br />\n";
      }
      echo "</p><p>Please try again.</p><p><br /></p>;"
      
    } //END of if (empty($errors)) IF.
     
  } //End of the main Submit conditional.
?>

