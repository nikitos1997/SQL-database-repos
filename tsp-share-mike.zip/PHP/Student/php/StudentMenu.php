<?php
    session_start();
?>
<div class="row">
            <div class="dropdown col-3 ml-4">
                  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <i class="fas fa-list-ul"></i></a>
                       
                      <div class="dropdown-menu bg-primary" aria-labelledby="dropdownMenuLink">
                        <a class="dropdown-item" href="student_review_draft.php">Review my drafts</a></a>
                        <a class="dropdown-item" href="student_agreement.php">Agreement form</a></a>
                        <a class="dropdown-item" href="student_new_request.php">New Bursary Request</a></a></a>
                        <a class="dropdown-item" href="student_home.php">Home</a></a>
                        <a class="dropdown-item" href="student_submitted.php">My submitted Forms</a></a>
                        <a class="dropdown-item" href="student_faq.php">FAQ's</a></a>
                    </div>
               </div>
