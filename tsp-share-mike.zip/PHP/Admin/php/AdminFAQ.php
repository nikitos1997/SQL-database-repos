<?php
    session_start();
    require_once 'connect.php';//connects to the SQL database.

    // drop down requirements on initial load (will run queries)
    // # - select
?>
            <div class="col-3">
                <ul class="list-group">
                    <li class="list-group-item  border-0">Submitted: <span>10</span></li>
                    <li class="list-group-item  border-0">Approved: <span>8</span></li>
                    <li class="list-group-item  border-0">Awaiting delivery: <span>YES</span></li>
                </ul>
            </div>
    
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet et velit ipsum recusandae nulla,
    reprehenderit ducimus pariatur esse, ad iste fugiat quibusdam odio corporis, iusto saepe magni architecto officiis amet.</p>
    
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet et velit ipsum recusandae nulla,
    reprehenderit ducimus pariatur esse, ad iste fugiat quibusdam odio corporis, iusto saepe magni architecto officiis amet.</p>
    