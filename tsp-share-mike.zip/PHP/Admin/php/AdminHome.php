<?php
    session_start();
    require_once 'connect.php';//connects to the SQL database.

    // drop down requirements on initial load (will run queries)
    // # - select
?>
                <div class="col-3">
                    <ul class="list-group">
                       <li class="list-group-item  border-0">Submitted: <span>10</span></li>
                        <li class="list-group-item  border-0">Approved: <span>8</span></li>
                        <li class="list-group-item  border-0">Awaiting delivery: <span>YES</span></li>
                    </ul>
                </div>
          
 <section class="container">         
            <h1 class="text-center" >Admin Home</h1>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi et voluptate nam, aliquid amet maiores fuga,
                    facilis ipsam soluta,
                    reprehenderit, explicabo repellat. Maiores libero mollitia esse illo. Nam, officia, quisquam!
                </p>
   </section>     
         
    