function deleteStudentDraft();
<?php
  
?>